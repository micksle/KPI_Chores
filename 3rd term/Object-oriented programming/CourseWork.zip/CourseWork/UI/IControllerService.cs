﻿namespace UI
{
    public interface IControllerService
    {
        string PrintMessage();
        void DoAction();
    }
}